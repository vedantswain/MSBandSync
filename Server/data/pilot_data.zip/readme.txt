Sensors are names in order of placement from wrist up:

- Sensor X = mBient
- Sensor B = Band-Vedant (elbow)
- Sensor A = Band-Kriti (wrist)

- X - B = 136 ms
- A - B = 1492 ms
- A - X = 1356 ms